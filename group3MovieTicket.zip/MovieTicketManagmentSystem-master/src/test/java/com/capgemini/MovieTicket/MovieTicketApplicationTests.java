package com.capgemini.MovieTicket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
